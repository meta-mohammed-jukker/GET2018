const sum = (a, b) => {
    return a + b;
};

const add = function (a){
  return function(b){
    return a+b;
  }
}

export {sum , add};

