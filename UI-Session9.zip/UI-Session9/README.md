# Getting started with webpack and ES6 modules – the demo

- This demo project is complimentary to the article, "[Getting started with webpack and ES6 modules](https://medium.com/@svinkle/getting-started-with-webpack-and-es6-modules-c465d053d988)"
- [See this demo in action](https://svinkle.github.io/getting-started-with-webpack-and-es6-modules-the-demo/)!
- Made with 💖 by [@svinkle](https://twitter.com/svinkle)
